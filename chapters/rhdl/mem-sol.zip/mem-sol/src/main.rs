use rhdl::prelude::*;
mod doc;
mod alu;
mod register;
mod register_file;
mod ram;
mod top;
mod control_unit;

use crate::{ram::sim_ram, register::sim_reg, register_file::sim_reg_file, top::sim_top};

fn main() -> Result<(), RHDLError> {
    sim_ram()?;
    sim_reg_file()?;
    sim_reg()?;
    sim_top()?;
    Ok(())
}
