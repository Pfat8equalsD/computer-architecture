use rhdl::prelude::*;
use rhdl_fpga::core::dff::*;

// alu
#[derive(Digital, PartialEq, Eq)]
pub struct AluInput<U: Unsigned + BitWidth + Eq + Copy> {
    pub op1: Bits<U>,
    pub op2: Bits<U>,
    pub select: Bits<U4>,
    pub carry_in: Bits<U1>,
    pub enable: Bits<U1>,
}

#[derive(Digital, PartialEq, Eq)]
pub struct AluOutput<U: Unsigned+ BitWidth + Eq + Copy> {
    pub rez: Bits<U>,
    pub zero_flag: Bits<U1>,
    pub sign_flag: Bits<U1>,
    pub transport_flag: Bits<U1>,
    pub parity_flag: Bits<U1>,
    pub overflow_flag: Bits<U1>
}

#[kernel]
fn param_alu<U: Unsigned> (_cr: ClockReset, _i: AluInput<U>) -> AluOutput<U>
where
    U: Unsigned + BitWidth + Eq + Copy, {
    //    TODO: implement ALU logic

        AluOutput::<U>{
            rez: bits(0),
            zero_flag: bits(0),
            sign_flag: bits(0),
            transport_flag: bits(0),
            parity_flag: bits(0),
            overflow_flag: bits(0),
        }
    }

type ALU<U> = Func<AluInput<U>, AluOutput<U>>;

pub fn new<U>() -> Result<ALU<U>, RHDLError> 
where
    U: Unsigned + BitWidth + Eq + Copy, {
        Func::try_new::<param_alu<U>>()
}


