use rhdl::prelude::*;
use rhdl_fpga::core::dff::*;

//  register file
#[derive(Debug,PartialEq,Eq,Digital,Default)]
pub enum Sel {
    #[default]
    RA,
    RB,
    RC,
    IS,
    XA,
    XB,
    BA,
    BB
}

#[derive(Digital, PartialEq, Eq)]
pub struct RegisterFileInput {
    pub oe: Bits<U1>,
    pub we: Bits<U1>,
    pub data_in: Bits<U1>,
    pub sel: Sel
}

#[derive(Synchronous,SynchronousDQ,Clone,Debug)]
struct RegisterFile {
    pub registers: [DFF<Bits<U16>>; 8]
}

impl Default for RegisterFile {
    fn default() -> Self {
        Self {
            registers: core::array::from_fn(|_| DFF::new(Bits::<U16>::default()))
        }
    }
}

impl SynchronousIO for RegisterFile {
    type I = RegisterFileInput;
    type O = Bits<U16>;
    type Kernel = register_file_kernel;
}

#[kernel]
pub fn register_file_kernel(_cr: ClockReset, _i: RegisterFileInput, _q: Q) -> (Bits<U16>, D) {

    match (_i.sel) {
        _ => ()
    }

    (bits(0), D { registers: [bits(0); 8]})
}