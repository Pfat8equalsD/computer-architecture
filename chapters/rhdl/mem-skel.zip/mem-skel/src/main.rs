use rhdl::prelude::*;

// mod alu;
// mod register;
// mod register_file;
mod ram;

use crate::ram::*;

fn main() -> Result<(), RHDLError> {
    let ram = Ram::default();

    let input = vec! [
         RamImput {
            oe: bits(0),
            we: bits(0),
            data_in: bits(5),
            address: bits(0)
        },
        RamImput {
            oe: bits(0),
            we: bits(0),
            data_in: bits(7),
            address: bits(0)
        }
    ];

    let input_data = input.into_iter().with_reset(1).clock_pos_edge(100);
    let vcd = ram.run(input_data)?.collect::<Vcd>();

    vcd.dump_to_file("ram.vcd")?;

    Ok(())
}
