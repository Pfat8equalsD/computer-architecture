use rhdl::prelude::*;
use rhdl_fpga::core::dff::*;

//  register
#[derive(Digital, PartialEq, Eq)]
pub struct RegisterInput {
    pub oe: Bits<U1>,
    pub we: Bits<U1>,
    pub data_in: Bits<U16>
}

#[derive(Synchronous,SynchronousDQ,Clone,Debug)]
struct Register {
    pub memory: DFF<Bits<U16>>
}

impl Default for Register {
    fn default() -> Self {
        Self{ 
            memory: DFF::new(Bits::<U16>::default())
       }
    }
}

impl SynchronousIO for Register {
    type I = RegisterInput;
    type O = Bits<U16>;
    type Kernel = register_kernel;
}

#[kernel]
fn register_kernel (_cr: ClockReset, _i: RegisterInput, _q: Q) -> (Bits<U16>, D) {

    (bits(0), D { memory: bits(0)})
}