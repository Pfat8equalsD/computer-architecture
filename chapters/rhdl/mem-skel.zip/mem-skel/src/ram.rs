use rhdl::prelude::*;
use rhdl_fpga::core::dff::*;

// ram
#[derive(Digital, PartialEq, Eq)]
pub struct RamImput {
    pub oe: Bits<U1>,
    pub we: Bits<U1>,
    pub data_in: Bits<U16>,
    pub address: Bits<U10>
}

#[derive(Synchronous,SynchronousDQ,Clone,Debug)]
pub struct Ram {
    pub memory: [DFF<Bits<U16>>; 1024]
}

impl Default for Ram {
    fn default() -> Self {
        Self {
            memory: core::array::from_fn(|_| DFF::new(Bits::<U16>::default()))
        }
    }
}

impl SynchronousIO for Ram {
    type I = RamImput;
    type O = Bits<U16>;
    type Kernel = ram_kernel;
}

#[kernel]
pub fn ram_kernel (_cr: ClockReset, i: RamImput, mut q: Q) -> (Bits<U16>, D) {

    // // q.memory[i.address.raw() as usize] = i.data_in;
    // for j in 0..1024 {
    //     let x = j;

    //     if x == i.address.raw() {
    //         q.memory[j] = i.data_in;
    //     }
    // }
    (q.memory[0], D {memory: q.memory})
}
